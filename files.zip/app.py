from flask import Flask, request, send_file, jsonify
from flask_cors import CORS
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import Table, TableStyle, Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_RIGHT, TA_CENTER
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame
from reportlab.lib.utils import ImageReader
import arabic_reshaper
from bidi.algorithm import get_display
import requests, io, base64, os
from datetime import datetime

app = Flask(__name__)
CORS(app)

SUPABASE_URL = 'https://rgmmtroobtxltcyykxtl.supabase.co'
SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJnbW10cm9vYnR4bHRjeXlreHRsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODUxODU2NTMsImV4cCI6MjEwMDc2MTY1M30.MxrlRj31hbPWVLJ3Fhw1h3q-vjdki3YNYpZqw9nGk-c'

MAROON = colors.HexColor('#5A1228')
GOLD   = colors.HexColor('#B8860B')
LIGHT  = colors.HexColor('#FDF8F9')
WHITE  = colors.white
MUTED  = colors.HexColor('#999999')
TEXT   = colors.HexColor('#2C2C2A')
W, H   = A4

STORES = [
    ("219-Al Faisaliayh (King Fahd Rd.)",            "الفيصلية - طريق الملك فهد"),
    ("280-Dahya King Fahad - Go station",             "ضاحية الملك فهد - محطة Go"),
    ("82-AlAqrabia (Prince Faisal Bin Fahed Rd.)",    "العقربية - طريق الأمير فيصل بن فهد"),
    ("270-Othman Ibn affan (AlNouzha)",               "عثمان بن عفان - النزهة"),
    ("51-AlRakah AlShamaliyah (King Fahed Rd.)",      "الراكة الشمالية - طريق الملك فهد"),
    ("208-AlJalawiyah (King Khalid St.)",             "الجلوية - شارع الملك خالد"),
    ("212-AlNur (King Saud Rd.)",                     "النور - طريق الملك سعود"),
    ("233-Al Qusur (Prince Mohammed Bin Fahad Road)", "القصور - طريق الأمير محمد بن فهد"),
    ("271-Al Fursan (Riyadh Rd.)",                    "الفرسان - طريق الرياض"),
    ("56-AlAzizia (King Khaled Rd.)",                 "العزيزية - طريق الملك خالد"),
    ("92-AlFaisalyah (Abu Bakr AlSdek St.)",          "الفيصلية - شارع أبو بكر الصديق"),
    ("53-Al Buhayrah",                                "البحيرة"),
]

FONT_REGISTERED = False

def ar(text):
    return get_display(arabic_reshaper.reshape(text))

def register_fonts():
    global FONT_REGISTERED
    if FONT_REGISTERED:
        return
    font_dir = os.path.join(os.path.dirname(__file__), 'fonts')
    pdfmetrics.registerFont(TTFont('Amiri', os.path.join(font_dir, 'Amiri-Regular.ttf')))
    pdfmetrics.registerFont(TTFont('Amiri-Bold', os.path.join(font_dir, 'Amiri-Bold.ttf')))
    FONT_REGISTERED = True

def fetch_orders(date):
    url = f"{SUPABASE_URL}/rest/v1/orders?date=eq.{date}&apikey={SUPABASE_KEY}"
    r = requests.get(url, headers={'Authorization': f'Bearer {SUPABASE_KEY}'})
    return r.json() if r.ok else []


LOGO_B64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKcBBgYGBgcGBwgIBwoLCgsKDw4MDA4PFhAREBEQFiIVGRUVGRUiHiQeHB4kHjYqJiYqNj40MjQ+TERETF9aX3x8p//CABEIAlcCYQMBIgACEQEDEQH/xAAyAAEBAQEBAQEBAAAAAAAAAAAABgUEAwIBBwEBAAMBAQAAAAAAAAAAAAAAAAECAwQF/9oADAMBAAIQAxAAAAKqAAAAAAAAAAAAAAAAAAOeHQy9RITAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACco8mNsWwkq2NAtygAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOLt5Itg1MrVRuFuYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD8laiJr1/tjI2S32LcQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGPPaeZT025h6xRi/mAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAT+NYc9eyeqOj9nH9cXFOW0nPNanTnYjXefoqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA88qeaWntBVJp52FnLbGZ5Go/U/jR7VcFv8BxUE4L/wDZ+gcwIAAAAAAAAAAAAAAAAAAAAAAAAAAPDPTr/KbOvPyjoosT4tVZCm5dBTpyNgpE8998tJ/c9s5TRS34mq/JflT4+A6Oi4k6xzgzAAAAAAAAAAAAAAAAAAAAAAAAAAxZmsk3R00UoWqPDgo2XhM206Yf1+6bbR2eLnc2r+S+atd8U3SIxOewJhvC/jWnLvT1Gbf0OcAAAAAAAAAAAAAAAAAAAAAAAAAADnir3mXiGrlOgE6+/Emd/wDsnvMe7H2CIH5t55vkv38aaGnOFaXB8A6eahN8OUAAAAAAAAAAAAAAAAAAAAAAAAAAABy9Qmse982kGpcVtyBbt25cpe/cHqsqHN99BWb86kmE8t3Cb79DI1zAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAPCX0J5v7+vGabWpIlLDHztlXB+bbgTMNDPaPbxJ2+yYKdfIL91lK1TnBmAAAAAAAAAAAAAAAAAAAAAAAAAAABhzdxEN/wA18isWmvCjnEn1pJzNjH/C3/YjbY+2VXeqP5+u+FeSUXYlpDnAAAAAAAAAAAAAAAAAAAAAAAAAAAAAT1D+JgG1iur6+ROv7/HGyosTPrERq0wVszXx/lay7YD9Z36Kr2fsFQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAObPz9tpJ/F3nrPXk0mcM3cF0UG3Cfqt5xzPops/eT2Gv0ePsyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5o66yGkx8vd0eHpsYatnPe1OxgFh+rx/Xu8ieX6+/tHvu+HuxBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADO0fkgezz53XaRYjWqoPTZ6c15fa/x1UGspPafcZgqAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABzT1UWj+3alGnGG37YZ1AwPD3ZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARfHdYbfB9PraX3ObtmYy4LWPsI2C3IAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATPzXo2ZZ+V7NOmyda/CE4gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYWHcYNe3F6vCvjX1+i/mgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPn68yUr5Gur1BblAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeXr5wkbKHt46/0W5AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH5+iJtPDpjYJxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+Pidx2v8AQHz9MgAH5+5x2/UDvtN79gd430FrlSGYAAAAAAAAAAAAAAAAAHF58P6vu8PphI0daAu1vUMwAHH7Q69J7SZrf8vJ4MfbShK1fo4Jz4Wq9SApleDI18hp/QH5+uYAB4+2an46orca9/VFbx3esfpFaGIAAAAAAAAAAAAAAAAAHD8aJP5MVE0tiXsFqNaxLGdSlhUpYbEhoZ7WnmNbJN32+PRnN00zUry1NM6ycnYx9dLI18gvfuU9mFKmhSpf8KnOx/FOdu4W61wt/A3jC087QTWhygAAAAAAAAAAAAAAAAAAfM2ym3kXS8KvykAvxAL8QC/EB22X6jnyv3CPCzjLFbCz9r8Tha+TrLMi9/GUGvSYJdiEXf6Qa7z0ym9g+y/jv4Hueejl6ZWhygAAAAAAAAAAAAAAAAAAYGXZl5mmFQQAAABk4VmXk6n7Inc6zLSFB3lQVAAAeXqI/wDLE0jOynEVv6xAKAAAAAAAAAAAAAAAAAAAADgO9CUa+wFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHFwzTSvSG+tgUE+a1mhB6zKm5MXIRZ9kBqm37xmib/ANSv2VXlhZBecuNjFl2QOgml+ZzjLP5muEtvKN/E3fNHfhcdEHYM/vklflpdfcRTKevrE+i9x8c3wx9eyY209wVAAAAAAAAAAAAAAAAAk8ujnHTUfeDQs5HYx6VpN6Obpp3ODL41Pf14+tf9+/fPRoc3VwHTzfXQUGbn56vV5+Ps06eDQ4EaPBdwivT89Pknl7ObQMjewdkxqmW6U827hbiMP9/KBOj99hzZXd7kAAAAAAAAAAAAAAAAAAfkr68Lbj2MfWaZNLNUqJrRztJObu4nafH7z+5p4FTLK+/l+/q/5tYVSpM62Z7p+ucT08XbxF7BXsEy0PH28Wnl38PcZGzjUZOb2Dpp7enI1GUzSzVKvthzgAAAAAAAAAAAAAAAAAASmbemkbv6ZELQ7Ih9CoJnca7ET0Vw5JG5IlvisENXdYwcG8JifSyErxW4RFuVlfOuLRvbSiGtPUrK512WiKLVIht/aAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPgPgH//EAAL/2gAMAwEAAgADAAAAIQAAAAAAAAAAAAAAAAABwwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHbQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGXSQAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAOABSBMaQAAAAAAAAAAAAAAAAAAAAAAAAAADDQSHQNcQXICQAAAAAAAAAAAAAAAAAAAAAAAAAAIEBJHCWQQBNQAAAAAAAAAAAAAAAAAAAAAAAAAAAATURaQDQYAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBSAcZbIYaQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYdbRUAIIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKUCQaOcKAQQAAAAAAAAAAAAAAAAAAAAAAAAAAAAFUAXKLURQQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEKdSUMZYQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMBEeRaMSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUYDZUcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFYaCQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATIYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA3wQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFJQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEwQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEOQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAEYRXQAAAAAAAAAAAAAAAAAAGcQAAACUNRCQKQAAFNAMQAAAAAAAAAAAAAAAAAAMFRAAAKSOUESAAQTWVVYAAAAAAAAAAAAAAAAAAAAOBTDDDEYRWJKCQSQAQRAAAAAAAAAAAAAAAAAAAAIQQAAAAEEAEQAAAEIYIQAAAAAAAAAAAAAAAAAAAABQQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACREBKQZXVSdENCOKcKNOTQAAAAAAAAAAAAAAAAAIaEcNZRZCRdJcAbRUAVcIQAAAAAAAAAAAAAAAAADAAGSBOeZaURRQOBBDQQAAAAAAAAAAAAAAAAAAAAUIUIMQMUMIQQcEMccQQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHPP/8QAAv/aAAwDAQACAAMAAAAQ888888888888888888//APPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPOP/PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLdPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPNvPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPOfPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPGqeeedPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPFOMADTUNPPPPPPPPPPPPPPPPPPPPPPPPPPPOZQeWTHKPfYdPPPPPPPPPPPPPPPPPPPPPPPPPPPIUEARHOSHAcXPPPPPPPPPPPPPPPPPPPPPPPPPPPDSEIOfKEAMSfPPPPPPPPPPPPPPPPPPPPPPPPPPPPPfRAMeaPCdPPPPPPPPPPPPPPPPPPPPPPPPPPPPPEEASaCUUYPfPPPPPPPPPPPPPPPPPPPPPPPPPPPPJQIDOMPAQPfPPPPPPPPPPPPPPPPPPPPPPPPPPPPOEAPWCWVcPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPBOLUVFdHPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPJCZCbHFfPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPUACSQfPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPDWYNdPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPICetvPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPOr9PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPHMvPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLfvPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPL3vPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPLDfPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPAPPPLUBZfPPPPPPPPPPPPPPPPPPFGZfPPMQcVMESVfPPIRXPPPPPPPPPPPPPPPPPPPLKFcMMCIZVQFKOcPPQBJPPPPPPPPPPPPPPPPPPPPJRAQQQRAQKADQDCBUQUfPPPPPPPPPPPPPPPPPPPHXfPPPPHfDPfPPPPHLbPPPPPPPPPPPPPPPPPPPPPPOfPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPIQAMMcbfAINNUIIFIUFAYfPPPPPPPPPPPPPPPPPAeRKcJbLNcEYQJT1AFFbPfPPPPPPPPPPPPPPPPPHQFFBCQbMcSFJQAAUIVfPPPPPPPPPPPPPPPPPPPLbLfTXHbTPHXLDLHTHPfPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPIAP/8QAJBEAAQMCBgIDAAAAAAAAAAAAAQACAxFQEiExMmFxQIFBgJD/2gAIAQIBAT8A8I8lBwOhs0gqwqDYe7M7aelDs92aY0ACg+c/VmlJLzwot4sz4nOeSmRhn3VrzZpHYWlQaGymZoJGae8vPCiFGCyyx6uHtRMxHgWeHae7MVCcnWeNmGv4bf/EAD8RAAIBAwIDAgoHBwQDAAAAAAECAwAEEQUSITFRE0EGFBUiMjRAUGFxJDNSU3KBkRAgYnOhosEjQmOxNWBw/9oACAEDAQE/APYo45JHCIhZjyAGTVxaXFsVE0ZQsMgH3NoM3Y6pbnuYlT+deFZ+mwj/AIv8+5rEsLy3KjJEq4H514U7vKKZ5dkMe5vBS1ieWeZ1yyYCZ6mvC1h9GXsznid/+Pc2gQLDpkBA4uCzH51r6RtpdwXA4YKnofc2meEFra6dHFKHMiZAA6Vqmt3GoYj27Iwc7R3/ADpLa4f0Y2NDTrr7A/WmsbpRkxGiCDgjB9wW+nyy4ZvNU1dae0I3Kdy9/wAKt9NjdQ7S7s9y1HbQRegg+dZAFPe2q8DKPy40l7bOcCQZPWp7WKcYYce5hU8DQSlG/I+2JBM6llQkDvFW8IllCM23PWksLZEK7Ac8yaklksiqqwdDyXvFXc15ImWjKRnuqKaWI5RiKXVn24MYJ600tzdOFySTyUUNMuui0mmXJYZ2gdc0i7UVc5wAM1qjo0ygHOF4+2aYc23yY1cWcM3HGG+0KnN/bqVLkr9oVYTwKT2oG8nIc1LPAiZdhg1IizTHxeM46VHpczemQo/WpbW4tX3rkgcmFLqdyOe0/MVZ3xnYoy4bGRir83IjLRtgD0gBx9tsrzxclWGVJzUU8UoyjA0QCMGp9OhkyV8w1PZTw5yMjqKileJw6HBFW+owyABzsauBFSWNtJxMYB6ioLSCA5QceWTV3MkcD7jxIIA9uVmUgqxB6iodTlTAkG4dahvbeXGGweh/ZNY28uSVweoqXS5lyUIYUHuoDjLLQ1K6H+4H5irWUywI5HEjjWooVuW4nBAI9u061iMIkdQSTwzRhhYYMa/pUmnW78gVPwow31t9W+9elR6mmcSoUPfUcscgyjA0yKwwyg/Ain061Y52Y+VRoqIEUYAGBWqMDcgdFAPt2lygwlM8VNX8k8catF1844q0meaBXYYNPPDGQHcAnlmpIIZ185QehqbTpYjuhYn4d9R6hdRHDedjuNJqsR9NGFPqduEypJPSpJGkdnbmT7dbzNDIHX8xUM0c8YZTkHmKAAGAMCikMt9Kkgz5g2ipEubJi0ZLR9DUGowSYDHYehqSCCcecoPQ0+kqfQkI+BFXNo9vjLqc8se4DHLAEngYlSBmo9RncYWDc3UVKLpJe2dSGznNQTJPCGHyIqfTInJKNsPTuoaddp6EoHyJp4dSUemSPgacvuO/Oe/PuCwuXjkEfNWOMUSkaljgADJqKaG4VtpyORBFO72N0wT0TxxXlWI4wjk9K8ZvX4x2+B/FRbVPsJU8kkkpLgBuRx7gifZIjdCDRCTxEZyrirW0W3D4YnJq9sp5pwy4IIAqC1htkzwyBxY1PqgBIiGf4jUl3cSelIcdB7igu54OCtw6GoZr26IwQiDmwFCtRuizmJT5o500bpjcpGRkZGPclrqEOxUcbCAB8KuLmOOFnDgnHm4NaNZ+O6gisMqvnvXhYV8YtkHch9yx+DV9Kkbo8RR1BByeGa0rSotPhKg7nbBd61+4E+py4OQgCD8vcuga5GkcVpPwIOEf/BrXdW8RgCJxlkBx8B1okkknmeZ9yx/WJ8xXhV65B/J9zRfWJ+IV4WR4ks5OqEfp7mBwc1rOrLqHi4RCBGvHPU/+nwaaJYVk7QjIzjFHn+2NN8iLnGTjNT6eIkB7XOWAqfT1iiL9rnGOGKm04Rws/a5wM4x7IIo+zYkcqtYEkuezY8ONX9rFAI9meOc5/csbMXBYsSFFHTLYggbs9c1Hb/SxC/XBq9sooY0KZyWxg1FpkIQbySe+r2wSKPtIycd4NWfqkX4aPM/thQPLGp5FgDirmwijjBDNksBxNXVhFFAzhmyMczU1hCkDuGYkLkeyCVxjlWnH6UnyNX9tJOI9mOGc5ryZddFryZddFryZddFqxgeCIq+Mls1axypLcFxgM+VpiDqox1/xWocBAT3SCr6OWSACMZO4HAq8H0WTP2as/VYvw02nXW5sICM8DmvJ139gfqK8m3X2R+tQafcpNGxUYDAnjV99Uv41/wC6v/VJPyq49Tf8HsthaMrRT7hgg8Ku7vxbZ5m7NeVx9z/dXlcfc/3V5XH3P91eVx9z/dUmquVwkYB61ZW0jvHcbhzJbNat9THx/wB9RS3wiT/SVsgENmrz1WTP2ag1IRRInZZwMZzXlb/h/rXlYfcn9a8rj7k/rUeqB5FTsiMkDOauYWmjCggHcDVzE0sDopGTjFXQxaSDonssWozRRqgVSAKnuJJ2BcjhyH70F/LDGEVVIq4upbgjfjA5AVHqU6IFwpAGBmp72eddrEAdB+6CQQQeIoapcAAYWm1O5JBG0Y7gKnv5pkKEADvx7Mil3VR3kCriwaCMuXB4gY9y2eniZA7sQO4CprGKB4GQscyqCDVxAJ49hJAyKudOjSJnjZsqMkGrbTo5Ild3biM4FT6YEjZ0cnAzg1Np8KQNIrsSFzR0+LxYyh2zs3AVBp0ckKuXYEjNW2nRSxB2kbjnAFT6Yqxs0bk4GcGo9MjeBXDNuKAihpsZmKb24IDQ0mPccyNjupdJj3HdISO4CrqyMUqKhJD8BSaVEFG92z34qex7KeNcko7AA02lR5Xa7c+OaMSiaRcnCkj+uKnhVOR7s/1x7HYur20eO4YNTRzxXUId2ZDICpJ+NX7sluSrEHI4irn1WTjx2VBYDsV7R25ZwDjFSjbbOuScIRk0n+pY/OPFQhjp+COPZkVns7EHpFVvYgwKZHbiM4BwBRULAVBJAUjJq3OLaI/wCrO4NxPK2MYUAUHbx5kydoizindhexLuOChJFTgG6tvhuq4gkkeFkbAVsmrzlB/OWrmbsYWfGSMYFNIxkZ+RJyRTSswxgAdPY7K2uY2R1ZdjAFhV3t2xZ5iVcVqXqp+Yq59Wk/DV0rSWrBBkkDFMGWzKnmIsGtNbdagdCRQ2DEQ+zyrUGCWpHXAFTK0lmQnMqMUFZbQKeDCPB+eKh9Uj/lj/AKrSfTl+Qpf/ACDfyhT+vxfyzVwwW5tSeWWFXQuiqmBgOoqRbsPbmeQEGUYFal6q3zHssWqOkap2YOBjOamvpZZEYgAK2QtXF+88ZQoByqTUpJImQoOIxmodSljjCFQ2BgGn1OV42QoOIwTVtevboyhQQTnjQ1CXtzLtHo4xVzevcKqlQMHNQalLFGEKhsciabVJWQqY1yQRmk1KRI1Ts14LjNWt01uWIUHNDUH7cy7BnbjFHUHM6y7BkDGKubx7jZlQNvLFR6pMqgMobHfU1/JK0ZKgBWBAqfUHmiKFAB/8B//EAEwQAAECBAEFCwsBBgMHBQAAAAECAwAEBRESECExQVETIjI0UmFxcoGRsRQVIDNCUFNgYnOhIzBDgpLB0SQ1oiVEVGNw4fFFZIDC8P/aAAgBAQABPwL5yemWWeGu0IqjS3koCTnNr/JlXRZ9CtqfCJQXmWeuPkyrouwlWxUSHG2en5MqCcUo5390UwXnEc1/kydUEyr1+TaKavDNo583yZOzaphf0DRANjeJdZWw2o6Sn5KcUEoUToAyN4A4jGN7fPCCkpGHRq+Sqs9hbS2Pa09mWkPqutonNa4+Sqsf8V/AMtISd3WrYn5Kq7f6ja9otkZl3XjZCe2JWWTLt4Rp1n5KmZdMw3gPfDVMlkaQVdMBISLAWyOVCTb0vDszwutsDgtqP4g1xepgd8ee5m/Ab/MCuL1sDvhusyyuGFJ/MNutui6Fg9HyAtxDacS1ADnhqYZevuawrIc0PVSUa9rGfph6svq9WkI/Jhx953huKV6bbi21YkKIMSdXCrIfzHle/pyqhlam0Iuoazoh6YdfVicVeEOLbUFIVYxT5/ylJQrM4B3xPifCv1ybarcH0UpUo2AJMN0qcX7IT1oFDVrfHdBoR/4j/TD9MmmQTbEObLSJw+oWep/b30pSUC6iAOeJmsITdLIxHbqhmrzSF3WcadkPS8vURurCwHNY/vD0s+wf1EEc+qJeTfmDvE5tuqJKQblRfSs6TBAIsRcRM0dledo4Ds1Q/JTLHDbzbRohCFrVhSkkxLUbW+r+EQ0wyyLNoA9Ga3Pyh3c+DizZJRRTMsEcse9330MNlxegQ1WJZZsoKT0wlSVAFJBEVhl7dd0zlHhlZ3UODcsWLVaG1K3BJfsDh30PVhhs2bRj/AiWm2ZlN0HPrGv0AlI0DJO1BErZOHEs6oNamtSUCPPM59HdHnqa5DfcYfqE0+LKXYbBlpcqp19LhG8Qb9vvet8Xb+5/TJLzb8ubtq7NUS1Sl5gYF71Ww6DExR2V52zgOzVDFFz3eXfmETShIy2JhpOm0PzT7/rFk82rIha0KCkqIMU+pF5Qad4eo7fRm5FqaG+zKGhULosyOCpKvxBpc98H8iHZZ9rhtqGRptTqwhNrnabRL0UDO8q/0iEoShISkWA971hF5MnYoH0JWpvsWB36NhiWnZeYG8Vn2HTCkpWkpULgxNUdabqYzjkwppxKsJQQrZaJekPuZ3N4PzEtIsS2dA33KMP1aXaUUgFREO1mYVwAEfmHHnXTv1lUSlQfls3CTyTEtPy8xwVWVyTlIBFjFQYSxMqSnRpGSlT6l/oOHP7J98TTO7S7je0QttbailabEegCRnES1XebzOb8fmJecl3+AvPs1+hP0wPXcazL1jbC0KQopULEegxU5trNixD6oRXEe2yezPCq2zbetLPTmiYfXMOlxWSTv5Wxblj3zMSrMwLLT0HXEzSX2s7e/T+fSl6tMtZlb8c+mJeoyr+hVlbDlmJRiYTZxPQdcTNImGrlvfp/MEEGxFj6dLkFJVu7gtyR77flJd/hoz7dcP0V1OdpWIbDphbbjZstJB5/RYqE0xoXcbDDFYYXmcGA/iErSsXSoEc2R1hl7htgw5RZZXAUpP5hVEd9l1J6c0eZZvlN98PsrYcLa9IyUXcTjBQMYz35vfy223E2WkEc8P0ZpWdpWHmOcQ/IzLHCRm2jR6LbrjRuhZT0QzWXk+tSF8+gwzU5R328J+qBny1wDGwddjkpK8M6j6gR77mH0S7RcVD1Um3DmVgGwR5TM/Hc/mMIqE4jQ8rtzw3W3h6xtKvxDNVlHNKsB+qHqfKTGfDY8pMP0Z9HqyFjuMLQtBstJB5/RamX2fVuEQ1W3h6xsK/Eee5b4bn4idmvKXsdrC1gMlM48z2+HvuuKNmE9J9JmZfYP6bhEMVrU8jtTCVys0jNhWNkPUZhXqyUfkQ9TJtr2MQ2p/YUZvFNYuSn33W0XaaXsV45WqO8toLxpFxoh+Wdl14XE+glSkm6SQYl6w6jM6MY264YmmJgfpr7NcOyzD3rGwYeoif3TluYw7TptrS3foz+jTJUsMb7hLzn33Ms7uw43tEEFJIOkZKbOoeaS2Tv0jvitrTubSdeK+RCFLUEpFyYVSJwJvvTzAwpKkmygQcgUUm4NjErWFp3r+ccrXDTzTqcSFgjI4y07w20npELpMmrQkp6DCqGn2X/AMRLUyXYOLhK5/ftWkv94QOv/fICRohS1LN1KJPPkoyLzSjsRC6y6iYUMAwA254tJz7N7X8RE1SXms7e/T+cqHFtqxIUQeaGK06nM6nFz64aqMo7+8tzHNAIOg+/9MVCmFu7jI3usbPQog/VeP0xUpcszKti84hiYdl142z/AN4k55qZGxetMTEjLzHCTn5Q0w/SJhHq9+PzCkKQbKSQefKFKToJENzk4k715fjDBdLKC7w7Z/fzM0y8paUnOnSInKSh262t6rZqh6WfZP6jZHhCG3HDZCSTzRTZMyzRxcNWmJ6VEywU+0M6YIIJB0iASkgg2MSlZ9mY/nENutui6Fg9EKQhYspIPTC6ZJK/dW6INFleU53wmjyY04ldJ/tDUrLs+raA5/f8+lyUnd2R7Wcf1iUn2ZhIz2XrTBIAuTmh2qSbeYKxdWE1qVJzpWIaeaeTdtYMVeTsd3QOv/fKCQbg2hM9Np0Pq8Y85z3xvwIFYnByT2Q1Wx+8a7RDL7T6cTar+/5qWRMNFCuw88PsOy7mBYgrUrSonK0640sLQqxiUmETcvcjmUIn6eqXViTnb8MqUqUbJBMIkJxehhXbm8YFHnDqSO2PMs3tR3xT5Cal38SrBNs/P8gVkDyW9s4UMktLqmHQ2mJij4GipDlyBoyUVwiYUjUpPhBAOYwqmSRN9y/JjyOQZTctoA+r/vC6rJNZkAq6BCq4r2WB3x57mPhogVxzWynviWe3ZlDmEi+r5AqqCqSXzZ8khMiXmAs6NBh6cl0Mle6JObNz5KMm83fYg5J6ppY3iN8vwh1515WJxZJyMSUy/wABvNt1Q1RPiu9iYap8o1obudpz/IKkhSSk6CImZdUu8pB7Oceg084ysLQbGHqw+tvClOA6zkbbW6sIQLkxKUppqynN+v8AA+RZmVamUYV9h2Q7R5lJ3lljugUueJ9V+RCaOlDS1PvWzatUHIlKlKCUi5MSMkmWb+s8I/JEzNNS6MSz0DbE3OuzKs+ZOpOWjyul9Q5k5PKGN03PdBi2fI8/u3lTu6ab5ujK02XXEIGkm0NoS2hKE6ALRPTG4MEjhHMIbvuqNuIfI70u0+mziLxMUVWlhd/pMOSz7R37ShFIk1A7utNuT/fJU3t0mMI0I8YlE4plkfV4fJc7OJYRYcM6BBNzcxSkYpm/JT8kvTU0xMugOHhaDCqnNkWxAdAgkk3JuclJZwslfKP4HyTVpY3Dw6FZZWWVMO4Ro1mEpCUhI0D5JIBFjE9TkoSXGtWkQhONaU7TaGGEMNhKfktYGBV9kSQvNM9b5MdzNr6piR42z0/Jj3qnOqYlzhfaP1j5Mdztr6pgZoGcD5LMYFY8Gu9oSLAD5MEpLpdLgRvv+tKloTwlARu7PxUd/wCx3Vvlp74CkkXBBEbo3y098JWlXBUDG6I5YhLiFcFQPv6tcaR9v+uRPBHR6dV4i52eOSRv5rmtPteGSiaJnsyUXjSvt+5npvCsoQjEoac9gOkwJ1aM7racHLQrEB05JqoMyyglYUSRfNHnmU2L7oBBAI1/sJielpc2WrPsEee2PhLhqrSrhsbp6ck1NtSqQV3z7I89StuC53Qy6h5pLiNBiYnZeXzLVn2Qa2xqbXDdYlFmxxJ6Y0i4itcaT9seORPBHpvOoZbK16BHnWR5+6GZuXcZU4k71OmPO0jz90S03LzGLctWnNBqsjc5/wARLz0q85gb09HuZ3iLvK8oOL+aJVseVTWNKGwG7FA2bYkcXkbF+TFa40j7f9cjPqW+qPTfd3JlxfJTClKUoqUbk5aQ+XJcoJzo8IrnAZ6TkkFblTUKOpKjDjinFqWrSTloz5W0ts+xo6DFa40j7Y8cieAno9OrcRX0jxySP+WTnb4ZKHpf6BBFiRFI46noPuZ2VVjLjSgCeElQukwZV94/rLRbWEDT2wBYWitcZR9v+uRv1aOgenVeIu9njkp7TZppunhYr5KHw3+gRXPVs9JyX/2L/BkpDTZlF3TfEo3yUU/4pY/5cVrjaftjxyN8BPR6dW4i50jxySP+WTn8Xhkof+8fwwq+I303ikccHVPumueva6mRNXmkpCQEZhsjz1ObEd0eepzYjujz1ObEd0eepzYjujz1ObEd0eepzYjuh+pzD7RbWE2OSWqQZlFNYM+fD25KGg/rL1ZhFc9Uz1sjaMdIt/yzkkakJZlaCi+e6Y0xReNnqGK1xtP2x45GKs+02EYUqtojz298JEee3vhIjz298JEeepnkN/mPPU1yG+4x56muQ33GJipvvtFtSUWOzJI/5ZOfxeGSh6ZjoEOesX0mKRx1PQfdFxe188Vv17XU/aS8hMvngEJ5RhhpuXbQ2n/zFc9Wz0nJT+JM9ETtNdZWShJUjm1Qhl1xVkIJOSi8bPUMVrjSft/1/ZyH+WTn8XhkoemY6Ew5w19Jij8dHVPuirrW3OoUhVjuf9YeedeVicVc5GUDcm83siMKdkYU8kRhTyRGFPJEYU8kRhTyRGFPJEYU8mLDZkrRISwQc+Iw9MvvYd0Xe2jJTBaRZ7fGJqqTDM2tIw4U6oNcXbMwL9MEkkkxRR/ildSFIQrhJB6Y3Jr4ae6NzRyB3RubfIHdG4M/CR3R5Ox8JHdHkzHwkd0bi18NPdG4M/CR3RVGmxJuEISNGrnyIfdQ2tCVWSrTkYmHWCS2q1xkpHHU9U+6KpJzDz6VNouMFo83TvwTEpSXisKeFkjVt/aVWWefQ1uab2Mebp34BhikzK1b8YEwhAQhKRoAtE/TJhb63W7KB1a483TvwTCKVOq/d4ekxIySZVJz3UdJ/ZOtpdbUg6CIdpk22qwRiG0QmmTqgf0rdMCnTpNtxMLoz4bBSoKVrEeQTl/UKimyCpe63OGdWz/qLUlKRJOlJsc3jG7v/FX3xRlLUw5dRO/+SXahKNmxdz82eBVZH4n4MT7iFU91STcEDxyUp9lmVcLi7b+PO8nfSruht1t1OJCgRC3G2xdawkc8GpyIPrvwYTUJJeh4dubxgEEXEGpyI/ffgwxNy75IbcvaFT8olRSXhcGGpyWdVhQ6CYdmWGbbo4BePL5P46YLjaU4isBO2DU5EfvvwYTUZJX74dubxgKChcG4h6dlWVYXHLHZphqflHVhCXbk8xgTcuXtxC9/sgzsoCRuyc0NTUu6SEOAkQuoySDYvDx8IbdadGJCwRC6jJoNi73Z4ZmWH/VuA5HpqXY9Y4BzR53k76Vd0MvsvJu2sGFrS2kqUbAa487SHxvwY8sltx3bdN5thtxDqErQbgw8+hkDFfPoAzkx5YpOdcs4E7cxhKkrSFJNwfclXmy2kMoOdWnoy/8AoX/7l+hR3SmZwXzKHhFa40n7eWlTC0TCW771eqHU4HXE7FERRjab6UGKgnDOvjnv354pfH2e3witH/Fp+2MlXTgEqjYi2WmzC2plCb71ZsR0xVOPvdnhDTimnAtOkRTM8+12+ELFlqHPAURex05ApQvYnPpyMuqacStOkGJyZ3CWLmv2ekwpSlqKlG5OSXfWw4Fo/wDMVBaXaapadBCT+cinVKbQ3qTf8xS+IM9vjDgxTM0T7DO97YlUHdpMIQWyc5OLhCJPermUDgh3N2+5Kxx09UZGqfIPsIUlOrTfPE80hmmOIQMwt45KZJMzCHFOXzZhChZRHPFJ46joMTyJHeuTA0aOeBUadwfJt71RE0WS+ss8DVEhxxjrRUE4Zx/reMUw2nWe3wisptNA7URTjadY6YqqrzrnNaJROKaZH1iJ1EmUBUxaw0QKjTk5hLZuqInTLqfJY4HdEtxlj7ifGKpx57s8MlMbd8rZXgVhz57ZtEOesX1jEgwl+ZQhWjXE60lmZcQnQDDKN0ebRylAd8VKXbl3wlGjBfJWFHc5VHNknpVlMgcKRvALHIFXoa+Y/wD2yJSpRskEnYIpqVJkmkqTY5/GJiXUshxsgLtbPoUNhjcplQbSJdtGDgqxXtDDIZbwg31k7T7krMsSlLwGjMrJJTq5Ve1B0iKitK6c4pJzHD45KH6l3rZKRx1PQYnny9MrOoGw7I05JDjjHWisotNg8pESysMwyfrEVlzFMhPJT4xKG00wfrETysU2+fr8IpKMU6j6QTFSfLs0vYjMMstxhn7ifGKpx57s8ISLqA54SkJSEjQBDnrF9Jik8dT0GKlx57p/pEpxqX+4nxitcaR9seOSsG6pfqZFTcytvc1OEp2ZE/5I51v65KGgWeX0D3QQCCDFRp/k5xo4BPdkbdKqQ+nkrHjkonqXutkpXGx1TkoaRjeOuwifAE4+Byop3HWemK4n1CunJNO7tMOL2mEKwrSrYbw6rE4tW1Riho37yuYCHc7q+sYoqQZhZ2IipgCee7PCJXjLH3E+MVTjz3Z4Q36xHSMjnrF9Jik8dT0GKjx1/piUF5pj7iYrXGk/bHjkrA30v9vImiXAPlH+mPMX/uP9P/eJthMvSltp1W8clD9S71vdE7PzTU44ErzDVExPzEwkJWRbmyMptSZpW1Y8clE9S91slJ44nqmFpwLUk6jaJCd8lWq6bhQh90vOrcPtGKfxxjrRWUXlQeSvI0jdHEI5SgIdTgdcTsURkoyLSpPKVEyjBMOp2LMSM35K7itcEWMTL+7vrcta8S3GWPuJ8YqnHnuzwhr1iOsMjuZ1fWMUnjqegxUeOv8ATEmbTbHXEVrjaftjJV2iuWZd5OntyMVWYZQEWSoDReHarNuaDg6ImFqco+JemyfHJQ/Uu9b3RU5d/wAqcXuZwnXG5ucg90S1PmH1DelKeUYm5fDTlNNJva2btjyaZ+A5/KYo6HENO40Eb7XHks1c/oOfymKXLvpmwVNKAAOkWip09wuF5pN78IRuDxNtyVfohySmmzYtK0aheJCXfE20S0sC+yJ5ouyjqRptm7I8lmfgOfymKZKPeVJUttSQnaLRUJR/ytwpaUQc+YXjyWZ+A5/KYkmtylWk2z2z9sVSnrWrdmhflCNxevbc1X6IXJTSMN2lZxfMLxKy0x5Sz+ivhjVFTl3zOOKDSiDbQOaEys1iT+gvTyci5aZxq/RXp2RTJd4TiFFtQAB0iJ+XmDNvHclnPqESstMeUs/orzLGqKuw8qZSUtqIwahHksz8Bz+UxgCmsCh7NjE1SX21EtDGn8xuD/wl90Ik5pZzMq7rRMMOCl7kBdQSnRHksz8Bz+UxRm3kIdxoIBItf/5xLWltClqOZIueyN3e/wCEc70f3j//xAAsEAEAAQIEBQMFAQEBAQAAAAABEQAhMUFRYRBxgZHwobHRIFBgwfHhMHCA/9oACAEBAAE/IfzLA5OBi9qhn4j3/DE2GoQnU7fhnhkNCfLh+GOMyDuTUt0L0j8MSFixzbUE1z934W2qEjC2/tpADCMjWDul/Cm/hC8GhJDHakNDEswj8KdNink4kSToOv4UiDT9nFWUher+FMZX0XCbt1yHWj95X1n8KnrFxNDV3R327FFBAwC1KBKxWI10+OpLrcCm4Xm2nQXL5UfG8ofNWzosPSobvVT+ANAvNRRChsYy4IErFTAbW71wqTAtaGJ5w27fWOCsxq0vIyvOi/33NX3ANTUvIyORTdDwSoSEtsNaQj53fB9IF4wAlomUu6PaadhuU/3RSwfG9Okji3xzOL28tKdvvR6VYqgrn5XB81BXmRDtFWhFf8d6iHqh1q9PU7CkAYkfpKfCTEb1I1lRZOqoKUsgmlYieN2oDfYu9foYC9NvC9Zh04IRf32Pu7eOxiuhXNobj0pGowRkowakA0fFM2Lu1gO6/AqW4Gc9qsOli4PowBORwcBAnIBvTVguS/ujSfV815p+6czHG2PHPABqMA+7+ie7hYJM3i6VCkSzf5DUv38oJYXf60xCswYTm60nZMsA6cARPBGKNDBZwhxUMWpopsB+9qZY7uoc4uXzVdzdUt34XTBaAetNHpz3ogIrBh938M637+iYfcDk1gJz2hRiAQjnTid5icmty6FNEjbaT21eiwhuNLO6GLEnOrWd3etTznzUMHxLOVBB0Af94qgEcRrFegWg8EbuN/FjJ+8MVE2p1LlM0xw/QgIiYJUMe/l+aHsb9qQcbUOif7pMeOHH6IXk93rUWxd57oo6mOT5VGaLgGQZcN9+nN/vOP2YODrUt0rD0pEUSE+gURGEqNXzMaiDoXxvAOTYUp0Fh6U+UGI2frPS0X8b5v3s226NqTHR1TbdQj6Yw63lRau9Qq5YKk4DRzsvTC7Hg9aP6cflVz9j4obI0ME1OCyV6N5ffttVCanlugkl4730pbrdFRwJoohjkrPXCkARk46kDenCAat2n9fe8MUwNXSme2/LV6aCGleGdNWDa6rG2hg70FaTZ/xqSdMUbPqEfSx0ebdqgTci6iC4PJfumeQQrTh6n3PvekDN0j6phseXajt47Srqa9eOY4VNrmlEy90emNIiiQn1okbOzu2+9rC4x56cZfWYe9WoFwcnl9AsowRhqO24t/up4C5uw6Ud1PPvTbu+edysaTrUiKJCfRIxDckyPvZobTo5UdcIiaJwAERI0GZWt/sBHBLqoAqFzrylZRiJDwKvDBGEqEDae6uSkuHo0jWPn5YzSm6G8/2UZclg4DkffXvyQ4EBSJg1vRJS8CZMaOaxRDdcNlRTHpfSpL9d6UiMOPApqUoqAGdNqR0F+K9DSCan39AIkjlTcpjzeXb6G2BO7Vl7y/PEojBczLmqHmFc/VTbHylHVRt2ptTIQ8WJc1GKIjFwF9rNFqCsn36/3kSzzpCDn5vxSI3OPdW2bhNWKyztDAowRjG/+0aEJCaJT1gZExKggOh7lQ3e6aiDdBJT83N6e1LbFyHxWEvJ0VASey/d+/i7IpspyVBhiu49NafCBiuFXcLQT64UBB9YPmo5HbLnWWRwHEeUtRivfy/tQWbz2rHHn/CKWg5uz6NR0nPU5/f+Y7oaqcQnJyTUqKtGEs8VRH5eoUZ7+kwqNn2vGQE0CaGnwOysa5r4V/XfFNXmADP4AWWLE8+CeQt10DOlbppRjy4Su/aoAgI4jS+zOgFTx5ndT0jEetXEDnOmW0PX5rMjkisCbxfgEKmM7W/APbx5LUN5KAyrQ4IsMZ+uEnHm6c9c8hZctOEApu29VZ/QP21GJ8xev4CWsoE2ayo8XqfRETfIahcQssvTSlVlp5OGCiwn4KUdbmHjRt0xl61ELd35KCIyxwc00AWGTXg6hEAZ1eUJ/wCB+EYmeTjyVf2FsYHPficap+14e9N+DpXt27tjjgVoUZkCHSpwe66024/tTR+DQWHLU5NBWA6veop0C3el6rILjfHgvlajqxrk7fd+FrkEuRu0iJKsrWC8R72/CYTibiEOGNKxuaHykxW7wRsva/CSAdo+B4kMDfSKLGAgOX4SyARxGrRxd+8pQ8THWij5ua6v4WwcCpoBc3a/4Y5ensV5O34Z5rSttvd/DBD19ikoTEacjU/CxIlCRE4bfCthAPwws81Z3dP/AGmFu2EsUmgyLGHH/goCrBSJKXRW8mBkrXLooNQDRmtXu022fRH796T7uBgdn1ys+YcDal1vbwDmYfvTMs41LNiXufZodok0T9T2ragNwNFmhEEqx4AJh1Skkv8AR807VhJ1/wCHRF0tJtkOlHWdwTb0oZvQjucAJaYT0IfNKIx2nGkC75btDbvsUR5uLek0ICCODXntXD0v1vfGNacat40wHp8MRF6sN+WpFzSYY0A545Y6VozJyTH2YjalRHXVUvyxeq9HqMe1ek+7h5fT6y10etOoVK7vGdUsHNhx8GB2eUrTezOeLBrIanmtXBtzGE/WB2eCJJw/O71tYp2rw+n2ZWefCmDs1aNwoidFXigAEAQFFn1Hu4eS0+tJzPa4QKMebFuDtVm7whHV9+CEUJPQy4bQV7lLwM3BS+p+sfRLOPzzqLVE86j237SI8GPCPTALsutf2XzX9l81/ZfNf2XzX9l81/ZfNWlEmBmzOvB0pxmXNw6aPPGlY3e3BIZeY6X4IWcoN9aVSuK14rUrwmrhC+GE4xXmNeY15jTldr5V5p+680/dBuRTBmzOvC/hPmd68FrXj9PtGXrJjOKZBPh/6CYzIYOmtJUGk4rN4mvPf70x8skJeatoXBSIokJXitSpYeT3f8/ScPzG9eK1qF3Y+0LIM3OapXY4nbpwACZJu1bH6wAAANhW24M4BAmVAh+W4KR0XdNEGmiRjUmB1M6ZCVZXnSK6P3Kj7NhCayCAwsr+ar+Sr+Jp/wADX8bVmLPJX8TSewbwGTgu/A9eEvxA58Aux9obX2YgvK50h85Qu3TeL/j/AKFE9ZuHvSePdKD74qL0CgjgQ5FBojN0DvXhlM3A1L9V4/8AWP8AljnoaeJyvjpklAwQTVtndgKjXzT7NYam06GAZP8A0VRuZNwV/Y1bKIEsxY/CV5nRL2U6JZURSMJuDgLQ9+BlQ8EjWpF7zK3zIopYPY3sVhj6v1UCQTUpRHBvfqh5MSkIx1oJWAl8SkemN6YCOAatT6tHXQkTBel4ROyHoU/B0zQUEmCXKhdhyPsrJlIg9ym4Uz2ZTStNUN6HvkoaVcFbCKbpOGo/12Pso5tOJg9nhjgdT2KLa1rWFR2xOZR18UqU8ftSBgkwXY6RUZV2afpFQaRsUi1uwnMGaMCKRM/sjSApf1rOt7b3UmGcnu8Zu7w5BjGv5rjFSpovZoyP5KeXvqQNPcaBUDFqGW1tyg4mpxcpkGvJ21tjNXFu/PW1TKuZIQw4mnAECBEHE34J9iv8oQsQAocSqVeC/XMTIaNLdZXZw2DY3WNeTvoMSics5aNcF+wsYKBoVdICh1+ySu7HBKV8FXb1HEt+3gcqlAMda2KR2oj5dqAFTZinZbGi5NHEMuWMqKxNIFGr3Vzcjuq21ntapZy9yKg2g+k0v8vGWink3XHlbGmrXXSJ0ILRCdjhB4u3hGG82ZnTV3wa1K7DOCpb40TuTQpMCjzRQnoxczmnAm8L0A4BY1BHmPCKaJ6HgPasAlpsBNqQ3VGRLZiNCwtjV0SKn0Sq8UxX7J+rdMnhrUf7m9TEBQ9PDx9qVWWvD6U224PQoCoCXg4o2JwHqWq5uD+tCHlzzurzzliuYg9lSD+BH7o+m9Hyx9aBWAl4seLtq5WIO9HrAANivBa15fSnPJeyvB6K81q4d9e/DDNOTLgY3h7eEsl5F+0H2IkI5lZ1xI1/HBKuBOSHh5u3Czz7cEvCBjzmjYgp4e1NPIvpQoyY1CeFvkWK2qeygOzHdqSHhM5/ykpc/cp5l7HVoACLvuKuOp4u2vJa8PBa15fSvB2phmp2a8dq4KS7O3Cz24PieDPIpiuanh4+32iHPGECMJqLuswIl4KgYU6Dh5u1LKtCS8Yp8TOulqksOSGNqEiGSNKQeTCtrx724KN8gxRi/GMcN3V7WpEiP2amW40MaZu9LbBFOEoeLtqVvH9nAQdPcry+leDtU92+7FeA1eAwPi4YzDjMDpVuEbf21NKWy9PDx9vtELrChJMK/oqCNYGP7Tv0ERiwFeEB5Y0QSbUxGE5UTJslMXOlHHC4jqUQtdE5oSkob2LlRGxJVgWo91UgZqmhcKCFc1vXZY1I18V8VIY0DLwExvc1d/pZ2zK9L05q+lnCHOM6mKAOqwgZoGWsUchlVvCwiUFZVcs85hpTatVQMIzoCAZiqRFEVAWqwAagT6Sjm1g0AYNEA8qQBkxgpJhLrqPc+wd2nbCUXYIsULhUYKiBDvj/APcUd5r6Al4Df//EACwQAQACAAUDAwQCAwEBAAAAAAEAERAhMUFRYXGRUIGxIGCh8OHxMMHRcID/2gAIAQEAAT8Q9EI/ZpgnF5q9hKoO0Jn0fZm2rzlP+jiV/ZlJhZ+FJTKHM+G/ZguZ+IFOEPz/AOzAsg60Gky2gX9RZ9loCuhH7levtJNQwGkTMSElXc9PsoQiM4AwcsahvfOJOrKttlVt9lVRlseYmFZ6qB9lILQh5WJYM+nUq+yiTdp9F3gLI3SZd+EIvcn7KlS2Fi0IkHO9n4BCm1QwB0CPxALVyCOISazlfnGR1e4w65Tc6VR8y3fe35kLnW7DIbxgpD1/X7YQSzmaKz7jBaIBauQEtWDpfjHDM4kai7p0dtB9ehW6s9nkjdz5DlKgCIjonrr08k+oG3ZwPgJrAddM1YgDpKkZA+Q9j6SKkpZHoEPJGj8IKFZnwvzEsjXWp85dV9WocoDizfRMbavWbBBhYgd1hYOi3na3gQ0Od5IREMnT+Bo8QpLjRS+wMoDM1q37qPNvWUBuMB4FCAnUZ+bzKMFXtfnJpajcoW+eb8T5wV+Q1ONxIUAFqxW0nXkejCikD9hR6uNptC0aQA3nQj3WDqvYyHIk3vv3i9U9KV8SVyuAQNvdzQX1PsIQVyvJ4qDqRtbPWgvCvYnbrCnvJLeWCFPef6sGEUwqDjF6gkzLOesjCTQrec78ERfkXRJF311pOvsHK0O5xbBeTIfdwJTTY12AwdsNrIgpRKpVK0TZxEsA5YBBG7i3Yyak6co73VWKNETeEF3ZviswSA1swO8A/wB+ce6apWD0D1cOBj6K3QKLsuZLkJgoE+bAZ1SP10kgJ8aCH2GGXbSwEWyVYYswxTB2LgZ/XvOL967B0OxoRTl1JASvrX7O2Ip7UCxHZGGTXjEcBSisix1esS8iq9Fx+QjWIof0IxYUIicJCa9yG1ALzwtrP2liNFmKp9do/wDOVuxR6GIoiKI5MBolzeOuJiyCRsUpeRgxqE02mwMpb1lCm5B0HZg7LfGu5L9kIiUifQ/ZAiNIkqO4XROkjdt9r0dHEfRT4BYUXQydyEexQ0O4/UCoAquRE1GgVClPrdpzlGTe5KntimTE/wBwnqXqfTcaPPV03J1YbPS4Uie5h0j9uHZ1JwBWwcXv6qaSnRgxl7rMrRHUwDueLs/XVY0dtqJwve6LLf8As40+nmjKlq55nO5Y15X9r/tA1kLEbHExQ9oUJg22/onn1strlg6voIqr0mh11znHmT2TOn42EjmTZ1TBtV4cpRZ2xC3i4MbanU3ZPvV+fpCIfG3vdjKsM32Tj2h8yRbqEQGAX1u4ejc3UA+oZni0tvurIj965calOFAXkId2XuXlmvnkh0iERKRPrQ1+kmX9bNibnoD/ALjZZqY6aLYUrRTbM3X0N/e1g9yV9dGI+IoN5fkBSpOVQyj2FJLfiBkX6d6eOkQiJSJiCoEy90Lf1u66LW7Qc35jnWW1RSOBOXvTXokSyLTyMWAIl6srL3SrUfMCN/elg9nBtX2sjoku90wwHUQnykszomoxCFV7GHZZerTdfiqLXh5vyQVx+6/d9dLvQcEQqVg0j0SJasC7UdXAAyP6DRcT7LGOruAWgVfcLGkzXDsFD13RECBpHJHA0X0YoXo5aZV1/V5vzkgpi0QT18ywEUWIxTr5PPqcvos2nuUGw8qm4PBOrcy4EPOHmP55kIDcyyaceyUP2YlDDNviax6/6S8kXVwK2eCI6pXIAvryq059BqnJHnY2+X/VAiA1ey7HJgLloovtEU0BDekiDAtXtxekJ3YUUopGHDkuiG4kAP8AB8CnWhY07xey6l8TG1HIL4VS5A8f7LnwtHwhxBCgW/OfX1hv983MLdQDVvihWMtIA6rGUb1pvKoRMN7B4g1v+rPoDmMTZ+bJ2xDhujkdkgQND92eaN7yfMft398ctBHJtj3YnAcz1/Jy2WpaCKJPM89kkKB41dPOLeJ1NHoNyJbkKSwpn7M5vvlxI5rNcvBBAo9HyRS9g/4mIaxbszf19gFUOSwwHeCr010O39X6muDU6KzBiSAsR2Y+bNR7aBjqgs9fLYK0DY/PSPRxC3wCNKXeI2CswB1wx36vqOp9gK1z7FVgY010Wm/LJHUdBkBgAclh3TA8XT7v9xi7aK2XQDIYWx3/AH2qJl3cW+DP66AD7AF602iFJD3aV7aafQb/AL3UR1DcganR9JoEVW1YpMqi65aZp0HWABQUfYhhJY5Fo+LZoe6SKVO9MeIuRx1PytUAxBQAlnNOAIT68loCD6mEf2o+yF1BDrGNhLHnU73OWJt2b+HhpBHat6+O/wBjsRNA6Mz7eJw+zF7vaUtXPQRK+btrX2EcIpBdWGj7G5pocuoGZBWdo9koHY6rV2FjFdAz62MC8u/KkuRy+yvD7K95fjSTSshtVbtmc1V31+yWr2CytrARdhtQDEeRalHquFR/7J0zDqOjtinoin6vNg2QTaAKD7JEayAsR1GGm2tWBvFoQZHl0SvOGfvr7LAZEsOiJnHQGRiPsuldx4hB3ny+zP1PKOO1mOybh9lva1Q8wt9AR4SCLoCe/wBlgtoiQRfKRveM7rzTsfZhsihqhqI0GH/tDRR2O3mBjUQivAz/AMB9g1VoJRkcoTo+DZHUiAoBuwaHlKQH2iKga1swIQ1FZ3r17R8YLnMtB+PrDputsDXwWHXUNvxdSAAQLd63Dbqj0Z65jRb6eQ7CIGfgY3ogIyAiWJmJKtlyFWq2AxOuKzzF3gqcgs/wGXtbsT920DH6ZQR5pgACIljLjunko6pAgZdTaeZdIUgUKaR6iSrWFgtcogPUkFViAf8ANwekrBsRiHDH8L9a66RRJtQUQY321xseUluu2U/DESNBo3mVitVVEkorW3X6Mb6nN5lB7ITMZWrRQhbf02PUoaUnxfraINGO4Mj3YjUb9XEesL5uanQx8nZ3atP32Ohi98QOJhRQpVOtfXzW/wAjDsmfAwBfx8suuiuJyq9HcqRA6a1CxHklEcgKe3eo5hA1iAKAMgIfaj8f4USl3UXCGrc2M0kYObBgnGMLLXF5rg7moUbIDA5arypO7o4Tm/atebPrpfn4WDTsfHhX2IgtiAZvbOM3+kxu4Yc0wy0R9Y2bNmzZspN2jZIarAQ+CKYfMpSesFqCc9/GDOqRnVuC1LgQFjSXOtCvVw9kOphLXALsB0J/ZT/dT/dS+q3dP9cRIFbetDy254F7D48P3POGR0vHpAyHUyalXXEo3MXff/HBUCGbJLgjm1MCtCywNf1HG5FgT5lG/GVOlMbEjStp68R+yERKRIq6MvPXJWf5X+/6msoWHX5kR9IWpWavTESJEoChsADChtHIagjseOP8BH+Aj/AR/gI/wEf4CP8AAwJsNOhg/bZVKAgoMpYFX2MNT9P2kFPn0+NrGMkZMEUosrdVrDqZfnzRXCjXzGsBSxpYaLiKmBCjWSbkcDIKVWVWANPelQXhHlsDrJhfz7LAnZwcAyQ+kPPNyVhpERan2lhGFpUfZqwigK/xsRakoCQ/XsFgyN5fE4gqRqeAogStZaR/bwXEG0HizBIVVpoy0/xFq9tGpe51Je5e8s66iEfMQt6QZWvMUEvwk/DaCapfBUMdUsWekZ6A+o2fZhysAekHIoBlmhNCNW2X2SgxzU6U5SkR9xyJP+6xwxV/dDmuITr0SpoSkfR4eGdPIM/mClU4LzByv1poh4LLEsSDVXgLyRljCDuVEiqHOMmpC7cuoLAvK4P7FuKhBSJDbwDqZhFlzgfy5JUW/TyEKvFrE7JF4WFDjvVqaPZvd9yma9gBqzbsWR5dAdKRDhdoDVxar/ewSORPUTXR4jsl1CT3KRQTFjYnLQ4Ggz0Fv5GJuPqogO9cx0EpIV/r0hGNVSsi+UAo1Gq4FC0qTpvHrs1uGKb3HAU8rAh6lLWB9ETws+pprGzy+gv3X5lVjL1Bw4XHvI3S2GwYQRR5qgP7Y4EhqfChAjzKHATy8NpUADdZYRfHZxN2wJpgfky06XLfQUSNSqLV3YiKNZ1rkzWtt4W5qrUa0wrnqEDiBqYI/BCmrN10SU9rm30I/bS1quCXRa98yYQ+8eG8mrlmthU/MnzxS52BlA5gX7PxDJnc7D6bBeiOpoDwnLh6M3FlLjBiELerOFKRWNWrYMdvOObVFlNEJQD0VBHHOI4HZXI/KCi2oXQ6FwgokTaX+ESrrQV9hFr8vekx1FflQ2zG+MGsu0ewgZtqJK6nXBh2iwDKT0YVzEgUDV+Nj+PMvbSKIZC1R94t1uGVIuqBcKCrQCkaMDmoAkuV9xaZnAaWBP6kYHdWjeSW3vgdNVw2XIysGrgJaztcAoh5tfXWKsw4SPwzKXrMPswpqOv+/REz5T2m3gWks797IQsnO+ODT2coEVW1Yq6ci/3bkqjzDi00AtwVxwIBNBJ5Rl8jDXatyp6idErlcb2FQeO8tKbSv+vMXLreJpfvB5SNAFqxEUZ+84Yf6cs41q1QKZzaAUGMngJPoRUBPuHmwy0YFGjSLgaTdOHSa9IjV9IRS4KxCkSEDObmavzgu/HSGGnXa/HBqjUwabW6MHaHhJtHKCz8v8pSxs7yICRA2JkjC/0ISH9iVuIZYe9GYCuYvuqxrjLfdQubnrtA3YaByphFNH4eH4UzV+JNvbGST8L8IVtviCs8fAUz+RgoWjLLktSRpoW1mS4fh/h6Rd/l3UTBiOn11MHuB1IYX8b8ZkAFq0QEN4/y0aOCXADKDpYF9mvMGgR2ejyiUbr7EHDcUNibVQa1BfZsHNvtxJRYgB0tUV7E1XISAUyy90I/gnSZ/Aw/Re+j7xtHT1G+yMJPwvwmUF34lADq4fsNx0EYNEprITQuK3h2pe9kqt5/1wPw/wAfSDXHq6gjaYSZrPLkB0GmDMxgWc0EuoV43a++5DZwQRBKjnfhTmM/Axb3pTpDXFlDsonBQlx/gx2C1WERbrABCag+0iJJ6IsoEVD6GTXPSZEPvJNxKdRqn3YjQMa5RRIej91VUz/wgzg1VTUUtX7h0qwdRD1rUwEG9ko3upg761MvZCZtfhqZLg27lkUBcj1DVVI2x0s2QTQmulyzDDzCZEjNy2FfTSPlRsmwlnu6/CkWO6JSzDUD2lkvZXZBMnpBr6KMaw3+gPq9sKlY10+msaJpCV/9LZRjpW0Si1ws/wD/2Q=="

def generate_pdf(date, orders):
    register_fonts()
    logo_bytes = base64.b64decode(LOGO_B64)
    logo_img   = ImageReader(io.BytesIO(logo_bytes))

    class BrandedPDF(BaseDocTemplate):
        def __init__(self, buf):
            super().__init__(buf, pagesize=A4,
                leftMargin=15*mm, rightMargin=15*mm,
                topMargin=58*mm, bottomMargin=22*mm)
            frame = Frame(self.leftMargin, self.bottomMargin,
                          W - self.leftMargin - self.rightMargin,
                          H - 58*mm - 22*mm, id='main')
            template = PageTemplate(id='main', frames=frame, onPage=self.draw_chrome)
            self.addPageTemplates([template])

        def draw_chrome(self, canv, doc):
            canv.setFillColor(MAROON)
            canv.rect(0, H - 49*mm, W, 49*mm, fill=1, stroke=0)
            logo_h = 38*mm
            iw, ih = logo_img.getSize()
            logo_w = logo_h * (iw / ih)
            canv.setFillColor(WHITE)
            canv.roundRect(10*mm, H - 46*mm, logo_w + 4*mm, logo_h + 4*mm, 5, fill=1, stroke=0)
            canv.drawImage(logo_img, 12*mm, H - 44*mm, width=logo_w, height=logo_h,
                           preserveAspectRatio=True, mask="auto")
            tx = 12*mm + logo_w + 8*mm
            canv.setFillColor(WHITE)
            canv.setFont("Helvetica-Bold", 19)
            canv.drawString(tx, H - 19*mm, "Fresh Arabic Bread")
            canv.setFont("Amiri-Bold", 18)
            canv.drawRightString(W - 14*mm, H - 19*mm, ar("خبز عربي طازج"))
            canv.setFont("Helvetica", 9)
            canv.setFillColor(colors.HexColor("#F0D0DC"))
            canv.drawString(tx, H - 28*mm, "Daily Order Sheet  -  Consolidated")
            canv.setFont("Amiri", 10)
            canv.drawRightString(W - 14*mm, H - 28*mm, ar("ورقة الطلب اليومية الموحدة"))
            d_parts = date.split("-")
            fmt_date = f"{d_parts[2]}/{d_parts[1]}/{d_parts[0]}"
            now_str  = datetime.now().strftime("%d/%m/%Y  %I:%M %p")
            canv.setFont("Helvetica", 8)
            canv.setFillColor(colors.HexColor("#E0B0C0"))
            canv.drawString(tx, H - 36*mm, f"Date: {fmt_date}     Generated: {now_str}")
            canv.setFont("Amiri", 9)
            canv.drawRightString(W - 14*mm, H - 36*mm, ar(f"التاريخ: {fmt_date}"))
            canv.setFillColor(GOLD)
            canv.rect(0, H - 56*mm, W, 7*mm, fill=1, stroke=0)
            canv.setFillColor(WHITE)
            canv.setFont("Helvetica-Bold", 8.5)
            canv.drawString(14*mm, H - 52*mm, "1 packet = 6 pcs of Arabic bread")
            canv.setFont("Amiri-Bold", 9.5)
            canv.drawRightString(W - 14*mm, H - 52*mm,
                ar("شاورمر — المنطقة الشرقية (الدمام والخبر)  |  ١ طرد = ٦ قطع خبز عربي"))
            canv.setFillColor(MAROON)
            canv.rect(0, 0, W, 15*mm, fill=1, stroke=0)
            canv.setFillColor(WHITE)
            canv.roundRect(10*mm, 2*mm, 12*mm, 11*mm, 3, fill=1, stroke=0)
            canv.drawImage(logo_img, 11*mm, 2.5*mm, width=10*mm, height=10*mm,
                           preserveAspectRatio=True, mask="auto")
            canv.setFillColor(WHITE)
            canv.setFont("Helvetica", 7.5)
            canv.drawString(24*mm, 6*mm, "Shawarmer® — Eastern Region Operations (Dammam & Khobar)")
            canv.setFont("Amiri", 8.5)
            canv.drawRightString(W - 14*mm, 6*mm,
                ar("شاورمر® — عمليات المنطقة الشرقية (الدمام والخبر)"))

    sEN     = ParagraphStyle("en",   fontName="Helvetica",      fontSize=8.5, textColor=TEXT,   leading=13)
    sAR     = ParagraphStyle("ar",   fontName="Amiri",          fontSize=11,  textColor=TEXT,   leading=14, alignment=TA_RIGHT)
    sHdrEN  = ParagraphStyle("hEN",  fontName="Helvetica-Bold", fontSize=9,   textColor=WHITE,  leading=12)
    sHdrAR  = ParagraphStyle("hAR",  fontName="Amiri-Bold",     fontSize=11,  textColor=WHITE,  leading=13, alignment=TA_RIGHT)
    sHdrPkt = ParagraphStyle("hP",   fontName="Helvetica-Bold", fontSize=9,   textColor=WHITE,  leading=12, alignment=TA_CENTER)
    sPktOn  = ParagraphStyle("pOn",  fontName="Helvetica-Bold", fontSize=11,  textColor=MAROON, leading=13, alignment=TA_CENTER)
    sPktOff = ParagraphStyle("pOff", fontName="Helvetica",      fontSize=11,  textColor=MUTED,  leading=13, alignment=TA_CENTER)
    sTotEN  = ParagraphStyle("tEN",  fontName="Helvetica-Bold", fontSize=10,  textColor=WHITE,  leading=13)
    sTotAR  = ParagraphStyle("tAR",  fontName="Amiri-Bold",     fontSize=12,  textColor=WHITE,  leading=14, alignment=TA_RIGHT)
    sTotNum = ParagraphStyle("tNum", fontName="Helvetica-Bold", fontSize=14,  textColor=WHITE,  leading=15, alignment=TA_CENTER)

    col_w = [68*mm, 68*mm, 24*mm]
    rows  = [[
        Paragraph("Store Name", sHdrEN),
        Paragraph(ar("اسم الفرع"), sHdrAR),
        Paragraph("Pkts", sHdrPkt),
    ]]
    total = 0
    for en, ar_name in STORES:
        o    = next((x for x in orders if x["store"] == en), None)
        pkts = o["packets"] if o else 0
        total += pkts
        rows.append([
            Paragraph(en, sEN),
            Paragraph(ar(ar_name), sAR),
            Paragraph(str(pkts) if pkts else "—", sPktOn if pkts else sPktOff),
        ])
    rows.append([
        Paragraph("Total (Pkts)", sTotEN),
        Paragraph(ar("المجموع (طرود)"), sTotAR),
        Paragraph(str(total), sTotNum),
    ])
    n = len(STORES)
    t = Table(rows, colWidths=col_w, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND",     (0,0),   (-1,0),   MAROON),
        ("ROWBACKGROUNDS", (0,1),   (-1,n),   [LIGHT, WHITE]),
        ("BACKGROUND",     (0,n+1), (-1,n+1), MAROON),
        ("LINEBELOW",      (0,0),   (-1,n),   0.3, colors.HexColor("#E0C0C8")),
        ("BOX",            (0,0),   (-1,-1),  0.5, colors.HexColor("#C09090")),
        ("TOPPADDING",     (0,0),   (-1,-1),  7),
        ("BOTTOMPADDING",  (0,0),   (-1,-1),  7),
        ("LEFTPADDING",    (0,0),   (-1,-1),  8),
        ("RIGHTPADDING",   (0,0),   (-1,-1),  8),
        ("VALIGN",         (0,0),   (-1,-1),  "MIDDLE"),
    ]))
    buf = io.BytesIO()
    doc = BrandedPDF(buf)
    doc.build([t])
    buf.seek(0)
    return buf

@app.route("/generate-pdf", methods=["GET"])
def generate_pdf_endpoint():
    date = request.args.get("date", "")
    if not date:
        return jsonify({"error": "date parameter required (YYYY-MM-DD)"}), 400
    try:
        orders = fetch_orders(date)
        pdf_buf = generate_pdf(date, orders)
        return send_file(pdf_buf, mimetype="application/pdf",
            as_attachment=True,
            download_name=f"shawarmer-bread-order-{date}.pdf")
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "Shawarmer Bread PDF Generator"})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
